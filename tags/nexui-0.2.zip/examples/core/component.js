var s;
$(function(){
	
require(['Nex/Component'], function(Component){

	Component.create({
		renderTo :　document.body	
	});

});
		
});		