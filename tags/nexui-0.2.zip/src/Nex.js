define(function(require){
	
	var lang = require('./core/lang');
	
	var Class = require('./core/Class');
	
	var ClassManager = require('./core/ClassManager');
	
	// Establish the root object, `window` (`self`) in the browser, `global`
	// on the server, or `this` in some virtual machines. We use `self`
	// instead of `window` for `WebWorker` support.
	var root = typeof self == 'object' && self.self === self && self ||
		typeof global == 'object' && global.global === global && global ||
		this;
		
	var Nex = {};
		
	// Export the Underscore object for **Node.js**, with
	// backwards-compatibility for their old module API. If we're in
	// the browser, add `_` as a global object.
	// (`nodeType` is checked to ensure that `module`
	// and `exports` are not HTML elements.)
	if (typeof exports != 'undefined' && !exports.nodeType) {
		if (typeof module != 'undefined' && !module.nodeType && module.exports) {
			exports = module.exports = Nex;
		}
		exports.Nex = Nex;
	} else {
		root.Nex = Nex;
	}	
	
	lang.extend( Nex, {
		version : '1.0',
		global : root,
		lang : lang,
		Class: Class,
		define: Class
	} );
	
	lang.extend(Nex, lang);
	
	lang.extend(Nex, {
		ClassManager : ClassManager,
		create: lang.bind(ClassManager.create, ClassManager),
		Create: lang.bind(ClassManager.create, ClassManager),
		getClass: lang.bind(ClassManager.get, ClassManager)
	});
	
	return Nex;
});