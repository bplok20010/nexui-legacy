define(function(require){
	
	require('Nex');
	
	(function($){
		$.each(['maxWidth', 'maxHeight', 'minWidth', 'minHeight'], function(i, fn){
			var ua = navigator.userAgent.toLowerCase();
			var ie8 = /msie 8/.test(ua);
			var ac1 = {
				maxWidth : 'outerWidth',
				minWidth : 'outerWidth',
				maxHeight : 'outerHeight',
				minHeight : 'outerHeight'
			};
			var ac2 = {
				maxWidth : 'width',
				minWidth : 'width',
				maxHeight : 'height',
				minHeight : 'height'
			};
			function isPerc(v){
				return (v+'').indexOf('%') === -1 ? false : true;	
			}
			$.fn[fn] = function( v ){
				return ( isPerc(v) || !ie8 ) ?
					this.css(fn, v) :
					this.each(function(x, el){
						var that = $(el);
						var pix = parseFloat(v, 10) - (that[ac1[fn]]() - that[ac2[fn]]());
						that.css(fn, pix);
					});
			};	
		});	
	})(jQuery);
	(function($){
		/*
		selection扩展
		*/
		jQuery.support.selectstart = false;
		jQuery.fn.extend({
			disableSelection: function() {
				return this.bind( ( $.support.selectstart ? "selectstart" : "mousedown" ) +
					".nex-disableSelection", function( event ) {
						event.preventDefault();
					});
			},
			enableSelection: function() {
				return this.unbind( ".nex-disableSelection" );
			}
		});
		/*
		兼容 jquery 1.9 以上 移除 $.support.boxMoal
		*/
		if( jQuery.support.boxModel === undefined ) {
			jQuery.support.boxModel = document.compatMode === "CSS1Compat";
		}
		/*
		是否支持 onselectstart 检查
		*/
		jQuery(function() {
			var body = document.body,
				div = body.appendChild( div = document.createElement( "div" ) );
				
			$.support.selectstart = "onselectstart" in div;
		
			// set display to none to avoid a layout bug in IE
			// http://dev.jquery.com/ticket/4014
			body.removeChild( div ).style.display = "none";
		});
	})(jQuery);
	
	return $;
	
});